package net.sf.minuteProject.configuration.bean.query;

import java.util.List;

public class NativeQuery extends Query {

	private List<String> parameters;
	private String query;
	
}
