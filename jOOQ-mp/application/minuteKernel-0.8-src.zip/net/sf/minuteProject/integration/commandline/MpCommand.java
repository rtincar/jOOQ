package net.sf.minuteProject.integration.commandline;

public class MpCommand {

	public static void main(String[] args) {
		//TODO 
		// with nothing open a mp prompt
		// -f :passing the file
		// -help :return help
	}
	
	
}
