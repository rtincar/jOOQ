package net.sf.minuteProject.plugin.xml.schema;

public class XmlUtils {

}
