package net.sf.minuteProject.configuration.bean.view;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

/**
 * @author Florian Adler
 *
 */
public class Task  extends AbstractConfiguration{

}
