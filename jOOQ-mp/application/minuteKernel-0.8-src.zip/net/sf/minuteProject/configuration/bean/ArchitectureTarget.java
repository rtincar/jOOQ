package net.sf.minuteProject.configuration.bean;

public class ArchitectureTarget extends AbstractConfiguration{

}
