package net.sf.minuteProject.configuration.bean.model.webservice;

public interface Field extends WsdlObject{

	public String getType();
	
}
