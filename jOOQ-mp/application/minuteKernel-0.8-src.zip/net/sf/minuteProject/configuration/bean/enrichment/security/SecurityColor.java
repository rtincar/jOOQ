package net.sf.minuteProject.configuration.bean.enrichment.security;

public class SecurityColor extends EntitySecuredAccess {

	
}
