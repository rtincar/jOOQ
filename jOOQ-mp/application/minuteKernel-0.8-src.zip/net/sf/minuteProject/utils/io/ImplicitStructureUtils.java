package net.sf.minuteProject.utils.io;

public class ImplicitStructureUtils {
 
	// get file path based on implicit structure def
	
	// get file name based on implicit structure def
	
	//pass parameter to execute script or prg
	
	// ability to execute a sequence of task
	
	// create script run them; (create wslt script and run it)
	// in Line add executable at the end + Shell.exe
	
	// ant task
	
}
