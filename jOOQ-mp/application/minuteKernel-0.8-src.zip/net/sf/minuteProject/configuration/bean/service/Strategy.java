package net.sf.minuteProject.configuration.bean.service;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class Strategy extends AbstractConfiguration{
	private Scope scope;

	public Scope getScope() {
		return scope;
	}

	public void setScope(Scope scope) {
		this.scope = scope;
	}
	
	
}
