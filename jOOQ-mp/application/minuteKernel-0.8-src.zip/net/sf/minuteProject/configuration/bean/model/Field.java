package net.sf.minuteProject.configuration.bean.model;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class Field extends AbstractConfiguration{

	private Entity entity;

	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	
	
}
