package net.sf.minuteProject.configuration.bean.xml.impl;



import net.sf.minuteProject.configuration.bean.AbstractConfiguration;
import net.sf.minuteProject.configuration.bean.xml.Element;

public abstract class AbstractElement extends AbstractConfiguration implements Element{

	public abstract String getText() ;

	
}
