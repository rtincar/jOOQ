package net.sf.minuteProject.loader.catalog.technologycatalog.node; //schema technology-catalog

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import net.sf.minuteProject.loader.catalog.technologycatalog.TechnologycatalogHolder;
import net.sf.minuteProject.configuration.bean.AbstractConfigurationLoader;
import net.sf.minuteProject.configuration.bean.Template;

public class TechnologyCatalog extends AbstractConfigurationLoader{

    private String _packageName;
   private String _name;
   private Technologies _technologies;

   public TechnologyCatalog() {
   }

   public String getTechnicalPackage(Template template) {
      return getPackageName();
   }

   public String getPackageName() {
      if (_packageName == null)
         _packageName = new String();
      return _packageName;
   }

   public void setPackageName(String _packageName) {
      this._packageName = _packageName;
   }
   
   public String getName() {
	  if (_name == null)
	     _name = new String();
	      return _name;
   }
	
   public void setName (String _name) {
      this._name = _name;
   }
   
   
   public Technologies getTechnologies() {
	  if (_technologies == null)
	     _technologies = new Technologies();
	      return _technologies;
   }
	
   public void setTechnologies (Technologies _technologies) {
      this._technologies = _technologies;
   }
   
   

}

