package net.sf.minuteProject.plugin.jpa;

import java.util.ArrayList;
import java.util.List;

public class Jpa2MetamodelElement {

	public String attribute, variable;
	public List<String> map = new ArrayList<String>();

}
