package net.sf.minuteProject.configuration.bean.model.webservice;

import java.util.List;

public interface Entity extends WsdlObject{

	public List<Field> getFields();
	
}
