package net.sf.minuteProject.configuration.bean.model.webservice;

import net.sf.minuteProject.configuration.bean.GeneratorBean;

public interface WsdlEntity extends GeneratorBean{

}
