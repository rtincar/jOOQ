package net.sf.minuteProject.configuration.bean.enrichment.group;

import java.util.List;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public interface Group {

	public List<String> getList();
}
