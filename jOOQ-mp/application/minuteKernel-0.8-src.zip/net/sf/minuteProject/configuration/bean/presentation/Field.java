package net.sf.minuteProject.configuration.bean.presentation;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class Field extends AbstractConfiguration{

}
