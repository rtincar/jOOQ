package net.sf.minuteProject.plugin.maven;

public class MavenModule {

	private String name;

	public MavenModule(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
