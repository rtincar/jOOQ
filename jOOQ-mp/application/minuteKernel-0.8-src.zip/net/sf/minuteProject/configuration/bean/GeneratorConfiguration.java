package net.sf.minuteProject.configuration.bean;

public class GeneratorConfiguration {

}
