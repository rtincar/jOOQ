package net.sf.minuteProject.configuration.bean.model.data.constant;

public enum Direction {
	IN, OUT, INOUT, NONE, ANY, RETURN;
}
