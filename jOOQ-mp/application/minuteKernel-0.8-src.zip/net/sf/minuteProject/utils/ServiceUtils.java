package net.sf.minuteProject.utils;

import net.sf.minuteProject.configuration.bean.Template;
import net.sf.minuteProject.configuration.bean.service.Scope;

public class ServiceUtils {

	public static boolean isToGenerate(Template template, Scope scope) {
		return true;
	}
}
