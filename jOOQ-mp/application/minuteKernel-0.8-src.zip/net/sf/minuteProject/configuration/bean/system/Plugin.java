package net.sf.minuteProject.configuration.bean.system;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class Plugin  extends AbstractConfiguration{
	private String className;

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	
}
