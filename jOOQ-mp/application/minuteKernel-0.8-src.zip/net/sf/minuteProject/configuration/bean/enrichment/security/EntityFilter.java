package net.sf.minuteProject.configuration.bean.enrichment.security;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class EntityFilter extends AbstractConfiguration{

}
