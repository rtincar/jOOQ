package net.sf.minuteProject.configuration.bean.model.webservice;

public interface Message extends WsdlObject{

}
