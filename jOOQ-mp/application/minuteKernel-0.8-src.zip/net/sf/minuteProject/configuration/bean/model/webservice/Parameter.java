package net.sf.minuteProject.configuration.bean.model.webservice;

public interface Parameter extends WsdlObject{

}
