package net.sf.minuteProject.configuration.bean.query;

import net.sf.minuteProject.configuration.bean.AbstractConfiguration;

public class Query extends AbstractConfiguration {

	private String type;
}
